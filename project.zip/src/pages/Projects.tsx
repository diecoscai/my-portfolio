const Projects = () => {
    return (
      <div className="min-h-screen bg-gray-100 dark:bg-gray-900 p-6">
        <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-8">My Projects</h1>
        {/* Add your project components here */}
      </div>
    );
  };
  
  export default Projects;
  