const Contact = () => {
    return (
      <div className="min-h-screen bg-gray-100 dark:bg-gray-900 p-6">
        <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-8">Contact Me</h1>
        {/* Add your contact form or details here */}
      </div>
    );
  };
  
  export default Contact;
  