import React from 'react';
import { Link } from 'react-router-dom';
import Button from './Button';

interface NavbarProps {
  darkMode: boolean;
  setDarkMode: (mode: boolean) => void;
}

const Navbar: React.FC<NavbarProps> = ({ darkMode, setDarkMode }) => {
  return (
    <nav className="bg-white dark:bg-gray-800 shadow-md">
      <div className="container mx-auto px-6 py-3 flex justify-center items-center">
        <div className="text-xl font-bold text-gray-800 dark:text-white mr-auto">
          Diego's Portfolio
        </div>
        <div className="space-x-4 flex items-center">
          <Link to="/" className="text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400">Home</Link>
          <Link to="/projects" className="text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400">Projects</Link>
          <Link to="/about" className="text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400">About</Link>
          <Link to="/contact" className="text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400">Contact</Link>
          <Button
            onClick={() => setDarkMode(!darkMode)}
            className="ml-4"
            variant="secondary"
          >
            {darkMode ? '🌙' : '☀️'}
          </Button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
