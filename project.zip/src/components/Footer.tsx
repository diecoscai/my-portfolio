import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-blue-500 dark:bg-blue-800 text-white py-6">
      <div className="container mx-auto text-center">
        <p>&copy; 2024 Diego Costa. All Rights Reserved.</p>
        <p>Email: diecoscai@gmail.com</p>
        <p>LinkedIn: <a href="https://www.linkedin.com/in/diego-costa-caivano" className="underline">Diego Costa</a></p>
      </div>
    </footer>
  );
};

export default Footer;
