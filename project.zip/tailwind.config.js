/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  extend: {
    animation: {
      'fade-in': 'fadeIn 1s ease-in-out',
    },
    keyframes: {
      fadeIn: {
        '0%': { opacity: 0 },
        '100%': { opacity: 1 },
      },
    },
    colors: {
      primary: '#1DA1F2',
      secondary: '#14171A',
    },
    fontFamily: {
      sans: ['Roboto', 'Helvetica', 'Arial', 'sans-serif'],
      mono: ['Source Code Pro', 'Monaco', 'Courier New', 'monospace'],
    },
  },
  plugins: [],
}

